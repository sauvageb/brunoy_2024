-- Table: boris.places

-- DROP TABLE IF EXISTS boris.places;

CREATE TABLE IF NOT EXISTS boris.places
(
    id integer NOT NULL DEFAULT nextval('boris.places_id_seq'::regclass),
    name character varying COLLATE pg_catalog."default",
    CONSTRAINT places_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS boris.places
    OWNER to etude;