package com.training.app.dao.jdbc;

import com.training.app.dao.base.TripDao;
import com.training.app.model.Place;
import com.training.app.model.Trip;
import com.training.app.util.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcTripDao implements TripDao {

    @Override
    public List<Trip> findAll() {
        List<Trip> tripList = new ArrayList<>();
        String query = "SELECT t.id, p1.id departure_id, p1.name departure_name, p2.id arrival_id, p2.name arrival_name, t.price FROM trips t JOIN places p1 ON p1.id = t.departure_id JOIN places p2 ON p2.id = t.arrival_id";
        try (PreparedStatement pst = ConnectionManager.getConnection().prepareStatement(query)) {
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Trip trip = mapToTrip(rs);
                tripList.add(trip);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tripList;
    }


    private Trip mapToTrip(ResultSet rs) throws SQLException {
        Trip trip = new Trip();
        trip.setId(rs.getLong("id"));
        trip.setPrice(rs.getLong("price"));

        Place departurePlace = new Place();
        departurePlace.setId(rs.getLong("departure_id"));
        departurePlace.setName(rs.getString("departure_name"));
        trip.setDeparture(departurePlace);

        Place arrivalPlace = new Place();
        arrivalPlace.setId(rs.getLong("arrival_id"));
        arrivalPlace.setName(rs.getString("arrival_name"));
        trip.setArrival(arrivalPlace);
        return trip;
    }

    @Override
    public Long create(Trip object) {
        return null;
    }

    @Override
    public Trip findById(Long aLong) {
        return null;
    }

    @Override
    public boolean update(Trip trip) {
    	String query = "UPDATE trips departure_place = ?, arrival_place = ?, price = ? WHERE id = ?";
		Connection connection = ConnectionManager.getConnection();
		try (	PreparedStatement pst = connection.prepareStatement(query)) {
				pst.setLong(1, trip.getDeparture().getId());
				pst.setLong(2, trip.getArrival().getId());
				pst.setFloat(3, trip.getPrice());
				pst.setLong(4, trip.getId());
				int rowsUpdated = pst.executeUpdate();
				connection.commit();
				return rowsUpdated > 0;
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
    }


	@Override
	public boolean delete(Long id) {
		String query = "DELETE FROM trips WHERE id = ?";
		Connection connection = ConnectionManager.getConnection();
		try(PreparedStatement pst = connection.prepareStatement(query)){
			
			pst.setLong(1, id);
			int rowsDeleted = pst.executeUpdate();
			connection.commit();
			return rowsDeleted> 0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}


}
