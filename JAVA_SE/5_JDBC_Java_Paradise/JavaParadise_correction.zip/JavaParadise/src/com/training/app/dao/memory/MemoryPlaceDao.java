package com.training.app.dao.memory;

import com.training.app.dao.base.PlaceDao;
import com.training.app.model.Place;

import java.util.ArrayList;
import java.util.List;

public class MemoryPlaceDao implements PlaceDao {

    private static Long placeId = 0L;
    private static List<Place> placeList = new ArrayList<>();

    @Override
    public Long create(Place object) {
        object.setId(++placeId);
        placeList.add(object);
        return placeId;
    }

    @Override
    public Place findById(Long id) {
        return placeList.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }

    @Override
    public boolean update(Place updatedPlace) {
        return placeList.stream()
                .filter(t -> t.getId() == updatedPlace.getId())
                .findFirst()
                .map(p -> {
                    p.setName(updatedPlace.getName());
                    return p;
                }).isPresent();
    }

    @Override
    public List<Place> findAll() {
        return placeList;
    }

	@Override
	public boolean delete(Long id) {
		Place placeToDelete = findById(id);
		return placeList.remove(placeToDelete);
	}
}
