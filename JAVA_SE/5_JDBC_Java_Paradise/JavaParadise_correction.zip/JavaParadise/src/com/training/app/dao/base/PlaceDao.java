package com.training.app.dao.base;

import com.training.app.model.Place;

public interface PlaceDao extends CrudGenericDao<Long, Place> {
//    Long create(Place place);
//    Place findById(Long id);
//    boolean update(Place place);
//    List<Place> findAll();
}
