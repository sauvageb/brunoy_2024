package com.training.app;

import com.training.app.dao.DaoFactory;
import com.training.app.dao.base.PlaceDao;
import com.training.app.dao.base.TripDao;
import com.training.app.model.Place;
import com.training.app.util.ConnectionManager;


public class Launcher {

    public static void main(String[] args) {
        PlaceDao placeDao = DaoFactory.getPlaceDao();
        //Place newPlace = new Place("Tokyo");
        //placeDao.create(newPlace);
        //placeDao.findAll().forEach(p -> System.out.println(p));  
        //System.out.println(placeDao.findById(1L));
        //Place p1 = placeDao.findById(1L);
        //p1.setName("Brunoy");
        //placeDao.update(p1);
        //placeDao.delete(1L);
        
        TripDao tripDao = DaoFactory.getTripDao();
        tripDao.findAll().forEach(t -> System.out.println(t));  
        
        // Closing project when shutdown
    	Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				ConnectionManager.closeConnection();
			}
		});

    }
}
