package com.training.app.dao.memory;

import com.training.app.dao.base.TripDao;
import com.training.app.model.Place;
import com.training.app.model.Trip;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MemoryTripDao implements TripDao {

    private static Long tripId = 0L;
    private static List<Trip> tripList = new ArrayList<>();

    @Override
    public Long create(Trip object) {
        object.setId(++tripId);
        tripList.add(object);
        return tripId;
    }

    @Override
    public Trip findById(Long id) {
        return tripList.stream().filter(t -> Objects.equals(t.getId(), id)).findFirst().orElse(null);
    }

    @Override
    public boolean update(Trip updatedTrip) {
        return tripList.stream()
                .filter(t -> t.getId() == updatedTrip.getId())
                .findFirst()
                .map(t -> {
                    t.setPrice(updatedTrip.getPrice());
                    t.setDeparture(updatedTrip.getDeparture());
                    t.setArrival(updatedTrip.getDeparture());
                    return t;
                }).isPresent();
    }

    @Override
    public List<Trip> findAll() {
        return tripList;
    }

	@Override
	public boolean delete(Long id) {
		Trip tripToDelete = findById(id);
		return tripList.remove(tripToDelete);
	}
}
