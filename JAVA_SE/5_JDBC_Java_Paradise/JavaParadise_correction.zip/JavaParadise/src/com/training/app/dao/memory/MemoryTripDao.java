package com.training.app.dao.memory;

import com.training.app.dao.base.TripDao;
import com.training.app.model.Trip;

import java.util.ArrayList;
import java.util.List;

public class MemoryTripDao implements TripDao {

    private static Long tripId;
    private static List<Trip> tripList = new ArrayList<>();

    @Override
    public Long create(Trip object) {
        object.setId(++tripId);
        tripList.add(object);
        return tripId;
    }

    @Override
    public Trip findById(Long id) {
        return tripList.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }

    @Override
    public boolean update(Trip updatedTrip) {
        return tripList.stream()
                .filter(t -> t.getId() == updatedTrip.getId())
                .findFirst()
                .map(t -> {
                    t.setPrice(updatedTrip.getPrice());
                    t.setDeparture(updatedTrip.getDeparture());
                    t.setArrival(updatedTrip.getDeparture());
                    return t;
                }).isPresent();
    }

    @Override
    public List<Trip> findAll() {
        return tripList;
    }
}
