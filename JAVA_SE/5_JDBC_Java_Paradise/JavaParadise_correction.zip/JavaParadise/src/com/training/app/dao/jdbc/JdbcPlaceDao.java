package com.training.app.dao.jdbc;

import com.training.app.dao.base.PlaceDao;
import com.training.app.model.Place;
import com.training.app.util.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JdbcPlaceDao implements PlaceDao {

	@Override
	public Long create(Place place) {
		String query = "INSERT INTO places(name) VALUES(?)";
		long autoIncrKey = -1L;
		try (PreparedStatement pst = ConnectionManager.getConnection().prepareStatement(query,
				Statement.RETURN_GENERATED_KEYS)) {

			pst.setString(1, place.getName());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();
			if (rs.next()) {
				autoIncrKey = rs.getLong(1);
			}
			rs.close();
			ConnectionManager.getConnection().commit();
		} catch (SQLException e) {
			try {
				ConnectionManager.getConnection().rollback();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			e.printStackTrace();
		}
		return autoIncrKey;
	}

	@Override
	public Place findById(Long id) {
		String query = "SELECT id, name FROM places WHERE id = ?";
		Connection connection = ConnectionManager.getConnection();
		try (
				PreparedStatement pst = connection.prepareStatement(query)) {

			pst.setLong(1, id);

			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					String name = rs.getString("name");
					return new Place(id, name);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean update(Place place) {
		String query = "UPDATE places SET name = ? WHERE id = ?";
		Connection connection = ConnectionManager.getConnection();
		try (	PreparedStatement pst = connection.prepareStatement(query)) {
				pst.setString(1, place.getName());
				pst.setLong(2, place.getId());
				int rowsUpdated = pst.executeUpdate();
				connection.commit();
				return rowsUpdated > 0;
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Place> findAll() {
		List<Place> placeList = new ArrayList<>();
		String query = "SELECT id, name FROM places";
		try (Connection connection = ConnectionManager.getConnection();
				Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				Long id = rs.getLong("id");
				String name = rs.getString("name");
				placeList.add(new Place(id, name));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return placeList;
	}

	@Override
	public boolean delete(Long id) {
		String query = "DELETE FROM places WHERE id = ?";
		Connection connection = ConnectionManager.getConnection();
		try(PreparedStatement pst = connection.prepareStatement(query)){
			
			pst.setLong(1, id);
			int rowsDeleted = pst.executeUpdate();
			connection.commit();
			return rowsDeleted> 0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
