package com.training.app.dao.base;

import com.training.app.model.Trip;

public interface TripDao extends CrudGenericDao<Long, Trip> {
}
